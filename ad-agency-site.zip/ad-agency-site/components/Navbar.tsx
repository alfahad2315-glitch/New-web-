"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { site } from "@/lib/site-config";

const links = [
  { href: "/", label: ui.nav_home },
  { href: "/portfolio", label: ui.nav_portfolio },
  { href: "/services", label: ui.nav_services },
  { href: "/about", label: ui.nav_about },
  { href: "/faq", label: ui.nav_faq },
] as const;

export function LangToggle() {
  const { lang, setLang } = useLang();
  return (
    <div className="flex rounded-full border border-line p-0.5 text-xs font-semibold" role="group" aria-label="Language">
      {(["en", "bn"] as const).map((l) => (
        <button
          key={l}
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={`rounded-full px-3 py-1 transition ${lang === l ? "bg-white text-black" : "text-muted hover:text-white"}`}
        >
          {l === "en" ? "EN" : "বাং"}
        </button>
      ))}
    </div>
  );
}

export default function Navbar() {
  const { t } = useLang();
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (pathname.startsWith("/admin")) return null;

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-300 ${
        scrolled || open ? "border-b border-line bg-ink/85 backdrop-blur-xl" : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <Link href="/" className="font-display text-lg font-extrabold tracking-tight" onClick={() => setOpen(false)}>
          <span className="text-gradient">●</span> {site.name}
        </Link>

        <div className="hidden items-center gap-7 lg:flex">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`text-sm transition hover:text-white ${pathname === l.href ? "text-white" : "text-muted"}`}
            >
              {t(l.label)}
            </Link>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <LangToggle />
          <Link
            href="/contact"
            className="hidden rounded-full bg-accent px-5 py-2 text-sm font-semibold text-black transition hover:brightness-110 sm:inline-block"
          >
            {t(ui.get_quote)}
          </Link>
          <button
            className="grid h-10 w-10 place-items-center rounded-full border border-line lg:hidden"
            onClick={() => setOpen((o) => !o)}
            aria-label="Menu"
            aria-expanded={open}
          >
            <span className="text-lg">{open ? "✕" : "☰"}</span>
          </button>
        </div>
      </nav>

      {open && (
        <div className="border-t border-line px-5 pb-6 lg:hidden">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className={`block border-b border-line py-4 text-lg ${pathname === l.href ? "text-white" : "text-muted"}`}
            >
              {t(l.label)}
            </Link>
          ))}
          <Link
            href="/contact"
            onClick={() => setOpen(false)}
            className="mt-5 block rounded-full bg-accent py-3 text-center font-semibold text-black"
          >
            {t(ui.get_quote)}
          </Link>
        </div>
      )}
    </header>
  );
}
