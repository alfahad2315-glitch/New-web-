"use client";

import type { T } from "@/lib/site-config";
import { useLang } from "@/lib/i18n";
import Reveal from "./Reveal";

export default function SectionHeading({ kicker, title, sub, center }: { kicker?: T; title: T; sub?: T; center?: boolean }) {
  const { t } = useLang();
  return (
    <Reveal className={`mb-12 ${center ? "mx-auto max-w-2xl text-center" : "max-w-2xl"}`}>
      {kicker && <p className="kicker mb-3 text-xs font-semibold uppercase tracking-[0.25em] text-accent">{t(kicker)}</p>}
      <h2 className="font-display text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">{t(title)}</h2>
      {sub && <p className="mt-4 text-muted">{t(sub)}</p>}
    </Reveal>
  );
}
