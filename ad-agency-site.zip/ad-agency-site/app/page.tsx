import Hero from "@/components/Hero";
import { CTA, FeaturedWork, HowItWorks, ServicesGrid, Testimonials } from "@/components/sections";

export default function HomePage() {
  return (
    <>
      <Hero />
      <ServicesGrid />
      <FeaturedWork />
      <HowItWorks />
      <Testimonials />
      <CTA />
    </>
  );
}
