import { NextResponse, type NextRequest } from "next/server";
import { isAdmin } from "@/lib/admin-auth";
import { LEAD_STATUSES, isDbConfigured, listLeads, updateLeadStatus, type LeadStatus } from "@/lib/leads";

export async function GET(req: NextRequest) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const leads = await listLeads();
    return NextResponse.json({ leads, dbConfigured: isDbConfigured() }, { headers: { "Cache-Control": "no-store" } });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Failed" }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  if (!isAdmin(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { id, status } = await req.json().catch(() => ({}));
  if (typeof id !== "string" || !LEAD_STATUSES.includes(status as LeadStatus)) {
    return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  }
  try {
    await updateLeadStatus(id, status as LeadStatus);
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Failed" }, { status: 500 });
  }
}
