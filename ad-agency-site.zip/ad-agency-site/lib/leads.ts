// Server-only helpers for saving and reading leads.
// Uses Supabase when configured; otherwise falls back to an in-memory list
// so you can try the site locally before setting anything up.
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export const LEAD_STATUSES = ["new", "in_progress", "done"] as const;
export type LeadStatus = (typeof LEAD_STATUSES)[number];

export type Lead = {
  id: string;
  created_at: string;
  company: string;
  contact_name: string;
  phone: string;
  email: string;
  video_type: string;
  length: string | null;
  budget: string | null;
  deadline: string | null;
  package: string | null;
  reference_links: string | null;
  details: string | null;
  file_path: string | null;
  file_url?: string | null;
  status: LeadStatus;
};

export type NewLead = Omit<Lead, "id" | "created_at" | "status" | "file_url">;

const BUCKET = "briefs";

let client: SupabaseClient | null = null;
function supabase() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  client ??= createClient(url, key, { auth: { persistSession: false } });
  return client;
}

export const isDbConfigured = () => supabase() !== null;

// ---- In-memory fallback (development only; data is lost on restart) ----
const g = globalThis as unknown as { __memLeads?: Lead[] };
const mem = (g.__memLeads ??= []);

export async function uploadBrief(file: File): Promise<string | null> {
  const db = supabase();
  if (!db) return null;
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  const path = `${new Date().toISOString().slice(0, 10)}/${crypto.randomUUID()}-${safe}`;
  const { error } = await db.storage.from(BUCKET).upload(path, file, {
    contentType: file.type || "application/octet-stream",
    upsert: false,
  });
  if (error) throw new Error(`File upload failed: ${error.message}`);
  return path;
}

export async function insertLead(lead: NewLead): Promise<Lead> {
  const db = supabase();
  if (!db) {
    const row: Lead = { ...lead, id: crypto.randomUUID(), created_at: new Date().toISOString(), status: "new" };
    mem.unshift(row);
    console.warn("[leads] Supabase not configured — lead stored in memory only.");
    return row;
  }
  const { data, error } = await db.from("leads").insert(lead).select().single();
  if (error) throw new Error(`Database insert failed: ${error.message}`);
  return data as Lead;
}

export async function listLeads(): Promise<Lead[]> {
  const db = supabase();
  if (!db) return mem;
  const { data, error } = await db.from("leads").select("*").order("created_at", { ascending: false }).limit(500);
  if (error) throw new Error(error.message);
  const leads = data as Lead[];
  // Create short-lived download links for uploaded files (bucket is private)
  const paths = leads.map((l) => l.file_path).filter((p): p is string => !!p);
  if (paths.length) {
    const { data: signed } = await db.storage.from(BUCKET).createSignedUrls(paths, 60 * 60);
    const map = new Map(signed?.map((s) => [s.path, s.signedUrl]) ?? []);
    for (const l of leads) l.file_url = l.file_path ? (map.get(l.file_path) ?? null) : null;
  }
  return leads;
}

export async function updateLeadStatus(id: string, status: LeadStatus) {
  const db = supabase();
  if (!db) {
    const row = mem.find((l) => l.id === id);
    if (row) row.status = status;
    return;
  }
  const { error } = await db.from("leads").update({ status }).eq("id", id);
  if (error) throw new Error(error.message);
}
