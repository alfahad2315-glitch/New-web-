import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import { CTA, HowItWorks, Pricing, ServicesGrid } from "@/components/sections";
import { ui } from "@/lib/ui";

export const metadata: Metadata = {
  title: "Services & Pricing",
  description: "Ad video packages: Basic, Standard and Premium. Prices in BDT and USD.",
  alternates: { canonical: "/services" },
};

export default function ServicesPage() {
  return (
    <>
      <PageHeader title={ui.nav_services} sub={ui.pricing_sub} />
      <Pricing />
      <HowItWorks />
      <ServicesGrid />
      <CTA />
    </>
  );
}
