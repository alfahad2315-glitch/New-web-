"use client";

import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { categories, works, type CategoryId } from "@/lib/site-config";
import { WorkGrid } from "./sections";

export default function PortfolioGallery() {
  const { t } = useLang();
  const [filter, setFilter] = useState<CategoryId>("all");
  const items = filter === "all" ? works : works.filter((w) => w.category === filter);

  return (
    <>
      <div className="mb-10 flex flex-wrap gap-2" role="tablist">
        {categories.map((c) => (
          <button
            key={c.id}
            role="tab"
            aria-selected={filter === c.id}
            onClick={() => setFilter(c.id)}
            className={`rounded-full border px-5 py-2 text-sm transition ${
              filter === c.id ? "border-accent bg-accent font-semibold text-black" : "border-line text-muted hover:text-white"
            }`}
          >
            {t(c.label)}
          </button>
        ))}
      </div>
      {items.length ? <WorkGrid key={filter} items={items} /> : <p className="text-muted">{t(ui.no_items)}</p>}
    </>
  );
}
