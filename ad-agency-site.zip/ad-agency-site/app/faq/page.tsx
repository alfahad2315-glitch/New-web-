import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import { CTA, FaqList } from "@/components/sections";
import { ui } from "@/lib/ui";
import { faqs } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "FAQ",
  description: "Answers about delivery time, payment, revisions and ownership of your ad video.",
  alternates: { canonical: "/faq" },
};

// FAQ structured data helps Google show your answers in search results
const jsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.q.en,
    acceptedAnswer: { "@type": "Answer", text: f.a.en },
  })),
};

export default function FaqPage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <PageHeader title={ui.faq_title} />
      <section className="px-5 py-16">
        <FaqList />
      </section>
      <CTA />
    </>
  );
}
