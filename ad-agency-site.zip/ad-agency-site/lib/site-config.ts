// =====================================================================
//  ✏️  আপনার সব তথ্য এই ফাইলে বদলান (Edit all your business info here)
// =====================================================================

export type Lang = "en" | "bn";
export type T = { en: string; bn: string };

export const site = {
  name: "FrameForge Studio",
  url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
  email: "hello@example.com",
  // WhatsApp number in international format, digits only (e.g. 8801712345678)
  whatsapp: "8801700000000",
  // Your Facebook page username (m.me/<username>)
  messenger: "yourpagename",
  facebook: "https://facebook.com/yourpagename",
  youtube: "https://youtube.com/@yourchannel",
  instagram: "https://instagram.com/yourhandle",
  linkedin: "https://linkedin.com/in/yourname",
  // Optional: Calendly / Cal.com link for a free consultation call. Leave "" to hide.
  bookingUrl: "https://cal.com/",
  // Showreel: a short MP4 (10–30s, < 10 MB). Put your file in /public and use "/showreel.mp4"
  showreelMp4:
    "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
  // Full showreel on YouTube (opened by the "Watch showreel" button)
  showreelYoutubeId: "aqz-KE-bpKQ",
  copyrightYear: 2026,
};

export const categories = [
  { id: "all", label: { en: "All", bn: "সব" } },
  { id: "product", label: { en: "Product Ad", bn: "প্রোডাক্ট অ্যাড" } },
  { id: "reels", label: { en: "Reels / Shorts", bn: "রিলস / শর্টস" } },
  { id: "explainer", label: { en: "Explainer", bn: "এক্সপ্লেইনার" } },
  { id: "corporate", label: { en: "Corporate", bn: "কর্পোরেট" } },
  { id: "motion", label: { en: "Motion Graphics", bn: "মোশন গ্রাফিক্স" } },
] as const;

export type CategoryId = (typeof categories)[number]["id"];

export type Work = {
  title: T;
  client: string;
  category: Exclude<CategoryId, "all">;
  platform: "youtube" | "vimeo";
  videoId: string; // YouTube or Vimeo video ID
  vertical?: boolean; // true for 9:16 reels
  featured?: boolean;
  gradient: string; // fallback thumbnail colors (used when no thumbnail)
  thumbnail?: string; // optional custom image in /public
};

// 🎬 Replace these with your own videos (videoId = the part after "v=" in a YouTube link)
export const works: Work[] = [
  { title: { en: "Sneaker Launch Ad", bn: "স্নিকার লঞ্চ অ্যাড" }, client: "StepUp Shoes", category: "product", platform: "youtube", videoId: "aqz-KE-bpKQ", featured: true, gradient: "from-orange-500 to-rose-600" },
  { title: { en: "Restaurant Menu Reel", bn: "রেস্টুরেন্ট মেনু রিল" }, client: "Spice Route", category: "reels", platform: "youtube", videoId: "aqz-KE-bpKQ", vertical: true, featured: true, gradient: "from-amber-400 to-red-600" },
  { title: { en: "Fintech App Explainer", bn: "ফিনটেক অ্যাপ এক্সপ্লেইনার" }, client: "PayNow", category: "explainer", platform: "youtube", videoId: "aqz-KE-bpKQ", featured: true, gradient: "from-sky-500 to-indigo-700" },
  { title: { en: "Company Profile Film", bn: "কোম্পানি প্রোফাইল ফিল্ম" }, client: "Delta Group", category: "corporate", platform: "youtube", videoId: "aqz-KE-bpKQ", gradient: "from-slate-500 to-slate-800" },
  { title: { en: "Logo Reveal & Brand Intro", bn: "লোগো রিভিল ও ব্র্যান্ড ইন্ট্রো" }, client: "Nova Tech", category: "motion", platform: "youtube", videoId: "aqz-KE-bpKQ", featured: true, gradient: "from-fuchsia-500 to-purple-800" },
  { title: { en: "Skincare Product Ad", bn: "স্কিনকেয়ার প্রোডাক্ট অ্যাড" }, client: "Glow Lab", category: "product", platform: "youtube", videoId: "aqz-KE-bpKQ", gradient: "from-pink-400 to-rose-700" },
  { title: { en: "Eid Sale Reel", bn: "ঈদ সেল রিল" }, client: "Trendy Bazar", category: "reels", platform: "youtube", videoId: "aqz-KE-bpKQ", vertical: true, gradient: "from-emerald-400 to-teal-700" },
  { title: { en: "SaaS Feature Walkthrough", bn: "SaaS ফিচার ওয়াকথ্রু" }, client: "CloudDesk", category: "explainer", platform: "youtube", videoId: "aqz-KE-bpKQ", gradient: "from-cyan-400 to-blue-700" },
  { title: { en: "Kinetic Typography Promo", bn: "কাইনেটিক টাইপোগ্রাফি প্রোমো" }, client: "Beat FM", category: "motion", platform: "youtube", videoId: "aqz-KE-bpKQ", gradient: "from-yellow-400 to-orange-700" },
];

export const clients = ["StepUp", "Spice Route", "PayNow", "Delta Group", "Nova Tech", "Glow Lab", "Trendy Bazar", "CloudDesk"];

export const stats = [
  { value: "150+", label: { en: "Videos delivered", bn: "ভিডিও ডেলিভারি" } },
  { value: "60+", label: { en: "Happy brands", bn: "সন্তুষ্ট ব্র্যান্ড" } },
  { value: "5+", label: { en: "Years experience", bn: "বছরের অভিজ্ঞতা" } },
  { value: "48h", label: { en: "Fastest delivery", bn: "দ্রুততম ডেলিভারি" } },
];

export const services = [
  { icon: "🛍️", title: { en: "Product Ads", bn: "প্রোডাক্ট অ্যাড" }, desc: { en: "Scroll-stopping ads that make your product the hero and drive sales.", bn: "এমন অ্যাড যা আপনার প্রোডাক্টকে হিরো বানায় আর বিক্রি বাড়ায়।" } },
  { icon: "📱", title: { en: "Reels & Shorts", bn: "রিলস ও শর্টস" }, desc: { en: "Vertical videos built for Facebook, Instagram, TikTok and YouTube Shorts.", bn: "ফেসবুক, ইনস্টাগ্রাম, টিকটক ও ইউটিউব শর্টসের জন্য ভার্টিকাল ভিডিও।" } },
  { icon: "💡", title: { en: "Explainer Videos", bn: "এক্সপ্লেইনার ভিডিও" }, desc: { en: "Turn complex ideas into simple, engaging stories.", bn: "জটিল আইডিয়াকে সহজ ও আকর্ষণীয় গল্পে রূপ দিই।" } },
  { icon: "✨", title: { en: "Motion Graphics", bn: "মোশন গ্রাফিক্স" }, desc: { en: "Logo animations, kinetic text and animated promos.", bn: "লোগো অ্যানিমেশন, কাইনেটিক টেক্সট ও অ্যানিমেটেড প্রোমো।" } },
  { icon: "🏢", title: { en: "Corporate Videos", bn: "কর্পোরেট ভিডিও" }, desc: { en: "Company profiles, event highlights and brand films.", bn: "কোম্পানি প্রোফাইল, ইভেন্ট হাইলাইট ও ব্র্যান্ড ফিল্ম।" } },
  { icon: "📣", title: { en: "Promo Videos", bn: "প্রোমো ভিডিও" }, desc: { en: "Launches, offers and seasonal campaigns that convert.", bn: "লঞ্চ, অফার আর সিজনাল ক্যাম্পেইনের জন্য প্রোমো ভিডিও।" } },
];

export const packages = [
  {
    id: "basic",
    name: { en: "Basic", bn: "বেসিক" },
    bdt: 3000,
    usd: 30,
    popular: false,
    features: [
      { en: "Up to 15-second video", bn: "সর্বোচ্চ ১৫ সেকেন্ডের ভিডিও" },
      { en: "1 revision", bn: "১ বার সংশোধন" },
      { en: "3-day delivery", bn: "৩ দিনে ডেলিভারি" },
      { en: "Royalty-free music", bn: "রয়্যালটি-ফ্রি মিউজিক" },
      { en: "1 format (9:16 or 16:9)", bn: "১টি ফরম্যাট (৯:১৬ বা ১৬:৯)" },
    ],
  },
  {
    id: "standard",
    name: { en: "Standard", bn: "স্ট্যান্ডার্ড" },
    bdt: 7500,
    usd: 75,
    popular: true,
    features: [
      { en: "Up to 30-second video", bn: "সর্বোচ্চ ৩০ সেকেন্ডের ভিডিও" },
      { en: "3 revisions", bn: "৩ বার সংশোধন" },
      { en: "5-day delivery", bn: "৫ দিনে ডেলিভারি" },
      { en: "Script writing + subtitles", bn: "স্ক্রিপ্ট রাইটিং + সাবটাইটেল" },
      { en: "2 formats (9:16 + 16:9)", bn: "২টি ফরম্যাট (৯:১৬ + ১৬:৯)" },
      { en: "Basic motion graphics", bn: "বেসিক মোশন গ্রাফিক্স" },
    ],
  },
  {
    id: "premium",
    name: { en: "Premium", bn: "প্রিমিয়াম" },
    bdt: 18000,
    usd: 180,
    popular: false,
    features: [
      { en: "Up to 60-second video", bn: "সর্বোচ্চ ৬০ সেকেন্ডের ভিডিও" },
      { en: "Unlimited revisions", bn: "আনলিমিটেড সংশোধন" },
      { en: "7-day delivery", bn: "৭ দিনে ডেলিভারি" },
      { en: "Script + professional voice-over", bn: "স্ক্রিপ্ট + প্রফেশনাল ভয়েস-ওভার" },
      { en: "All formats + 3 cut-downs", bn: "সব ফরম্যাট + ৩টি ছোট ভার্সন" },
      { en: "Advanced motion graphics & color grade", bn: "অ্যাডভান্সড মোশন গ্রাফিক্স ও কালার গ্রেড" },
      { en: "Source files included", bn: "সোর্স ফাইল সহ" },
    ],
  },
];

export const steps = [
  { title: { en: "Brief", bn: "ব্রিফ" }, desc: { en: "Tell me about your brand, goal and audience.", bn: "আপনার ব্র্যান্ড, লক্ষ্য আর দর্শক সম্পর্কে জানান।" } },
  { title: { en: "Script", bn: "স্ক্রিপ্ট" }, desc: { en: "I write the script and storyboard for your approval.", bn: "আমি স্ক্রিপ্ট ও স্টোরিবোর্ড বানিয়ে আপনার অনুমোদন নিই।" } },
  { title: { en: "Production", bn: "প্রোডাকশন" }, desc: { en: "Shooting, editing, animation, music and sound.", bn: "শুটিং, এডিটিং, অ্যানিমেশন, মিউজিক ও সাউন্ড।" } },
  { title: { en: "Revisions", bn: "সংশোধন" }, desc: { en: "You review and I polish until it is perfect.", bn: "আপনি দেখে মতামত দেন, আমি নিখুঁত করি।" } },
  { title: { en: "Delivery", bn: "ডেলিভারি" }, desc: { en: "Final files in every format you need, ready to post.", bn: "প্রয়োজনীয় সব ফরম্যাটে ফাইনাল ফাইল, পোস্ট করার জন্য তৈরি।" } },
];

export const testimonials = [
  { name: "Rafiq Ahmed", role: { en: "Founder, StepUp Shoes", bn: "প্রতিষ্ঠাতা, StepUp Shoes" }, quote: { en: "Our launch ad got 3x more engagement than anything we made before. Super professional and fast.", bn: "আমাদের লঞ্চ অ্যাড আগের যেকোনো ভিডিওর চেয়ে ৩ গুণ বেশি এনগেজমেন্ট পেয়েছে। খুবই প্রফেশনাল আর দ্রুত।" } },
  { name: "Nusrat Jahan", role: { en: "Marketing Manager, Glow Lab", bn: "মার্কেটিং ম্যানেজার, Glow Lab" }, quote: { en: "He understood our brand instantly. The reels look premium and our sales went up during the campaign.", bn: "আমাদের ব্র্যান্ড খুব দ্রুত বুঝে ফেলেছেন। রিলগুলো প্রিমিয়াম লাগে, ক্যাম্পেইনে বিক্রিও বেড়েছে।" } },
  { name: "Tanvir Hasan", role: { en: "CEO, PayNow", bn: "সিইও, PayNow" }, quote: { en: "The explainer video made our app so easy to understand. Highly recommended!", bn: "এক্সপ্লেইনার ভিডিওটা আমাদের অ্যাপকে খুব সহজে বোঝাতে পেরেছে। অবশ্যই রেকমেন্ড করব!" } },
];

export const faqs = [
  { q: { en: "How long does a video take?", bn: "একটা ভিডিও বানাতে কত সময় লাগে?" }, a: { en: "Usually 3–7 days depending on the package. Rush delivery (48 hours) is available for an extra fee.", bn: "প্যাকেজ অনুযায়ী সাধারণত ৩–৭ দিন। অতিরিক্ত চার্জে ৪৮ ঘণ্টায় জরুরি ডেলিভারিও সম্ভব।" } },
  { q: { en: "How do I pay?", bn: "কীভাবে পেমেন্ট করব?" }, a: { en: "50% advance to start, 50% before final delivery. bKash, Nagad, bank transfer and Payoneer/PayPal for international clients.", bn: "কাজ শুরুর আগে ৫০% অগ্রিম, ফাইনাল ডেলিভারির আগে বাকি ৫০%। বিকাশ, নগদ, ব্যাংক ট্রান্সফার; বিদেশি ক্লায়েন্টদের জন্য Payoneer/PayPal।" } },
  { q: { en: "Do you shoot on location or only edit?", bn: "আপনি কি লোকেশনে শুটিং করেন, নাকি শুধু এডিট?" }, a: { en: "Both. I can edit your footage, create fully animated videos, or arrange a shoot in Dhaka (cost depends on the location and crew).", bn: "দুটোই। আপনার ফুটেজ এডিট, পুরো অ্যানিমেটেড ভিডিও, অথবা ঢাকায় শুটিং (লোকেশন ও ক্রু অনুযায়ী খরচ)।" } },
  { q: { en: "What do I need to provide?", bn: "আমাকে কী কী দিতে হবে?" }, a: { en: "Your logo, product photos or footage, key message and any reference videos you like. I'll guide you through the rest.", bn: "লোগো, প্রোডাক্টের ছবি বা ফুটেজ, মূল মেসেজ আর আপনার পছন্দের রেফারেন্স ভিডিও। বাকিটা আমি গাইড করব।" } },
  { q: { en: "Who owns the final video?", bn: "ফাইনাল ভিডিওর মালিকানা কার?" }, a: { en: "You do. After full payment you get full commercial rights to use the video anywhere.", bn: "আপনার। সম্পূর্ণ পেমেন্টের পর ভিডিওটি যেকোনো জায়গায় ব্যবহারের পূর্ণ বাণিজ্যিক অধিকার আপনার।" } },
  { q: { en: "Can I get a custom package?", bn: "কাস্টম প্যাকেজ পাওয়া যাবে?" }, a: { en: "Yes! Fill in the quote form with your needs and budget and I'll send a custom offer within 24 hours.", bn: "অবশ্যই! কোট ফর্মে আপনার চাহিদা ও বাজেট লিখুন, ২৪ ঘণ্টার মধ্যে কাস্টম অফার পাঠাব।" } },
];

export const videoTypes = categories.filter((c) => c.id !== "all");

export const budgetRanges = [
  { en: "Under ৳5,000 / $50", bn: "৳৫,০০০ / $৫০-এর কম" },
  { en: "৳5,000 – ৳10,000 / $50 – $100", bn: "৳৫,০০০ – ৳১০,০০০ / $৫০ – $১০০" },
  { en: "৳10,000 – ৳25,000 / $100 – $250", bn: "৳১০,০০০ – ৳২৫,০০০ / $১০০ – $২৫০" },
  { en: "৳25,000+ / $250+", bn: "৳২৫,০০০+ / $২৫০+" },
  { en: "Not sure yet", bn: "এখনো ঠিক করিনি" },
];

export const lengths = [
  { en: "Up to 15s", bn: "১৫ সেকেন্ড পর্যন্ত" },
  { en: "15–30s", bn: "১৫–৩০ সেকেন্ড" },
  { en: "30–60s", bn: "৩০–৬০ সেকেন্ড" },
  { en: "1–3 min", bn: "১–৩ মিনিট" },
  { en: "3+ min", bn: "৩+ মিনিট" },
];
