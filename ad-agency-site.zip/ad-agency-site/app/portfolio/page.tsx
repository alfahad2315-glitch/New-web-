import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import PortfolioGallery from "@/components/PortfolioGallery";
import { CTA } from "@/components/sections";
import { ui } from "@/lib/ui";

export const metadata: Metadata = {
  title: "Portfolio",
  description: "Product ads, reels, explainer, corporate and motion graphics videos made for brands.",
  alternates: { canonical: "/portfolio" },
};

export default function PortfolioPage() {
  return (
    <>
      <PageHeader title={ui.portfolio_title} sub={ui.portfolio_sub} />
      <section className="mx-auto max-w-7xl px-5 py-16">
        <PortfolioGallery />
      </section>
      <CTA />
    </>
  );
}
