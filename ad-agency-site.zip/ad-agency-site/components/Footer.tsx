"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { site } from "@/lib/site-config";

export default function Footer() {
  const { t } = useLang();
  const pathname = usePathname();
  if (pathname.startsWith("/admin")) return null;

  const socials = [
    { label: "Facebook", href: site.facebook },
    { label: "YouTube", href: site.youtube },
    { label: "Instagram", href: site.instagram },
    { label: "LinkedIn", href: site.linkedin },
  ];

  return (
    <footer className="border-t border-line">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3">
        <div>
          <p className="font-display text-xl font-extrabold">
            <span className="text-gradient">●</span> {site.name}
          </p>
          <p className="mt-3 max-w-xs text-sm text-muted">{t(ui.hero_sub)}</p>
        </div>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <Link href="/portfolio" className="text-muted hover:text-white">{t(ui.nav_portfolio)}</Link>
          <Link href="/services" className="text-muted hover:text-white">{t(ui.nav_services)}</Link>
          <Link href="/about" className="text-muted hover:text-white">{t(ui.nav_about)}</Link>
          <Link href="/faq" className="text-muted hover:text-white">{t(ui.nav_faq)}</Link>
          <Link href="/contact" className="text-muted hover:text-white">{t(ui.nav_contact)}</Link>
        </div>
        <div className="text-sm">
          <a href={`mailto:${site.email}`} className="block text-white hover:text-accent">{site.email}</a>
          <a href={`https://wa.me/${site.whatsapp}`} target="_blank" rel="noopener" className="mt-1 block text-muted hover:text-white">
            WhatsApp: +{site.whatsapp}
          </a>
          <div className="mt-4 flex flex-wrap gap-3">
            {socials.map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noopener" className="rounded-full border border-line px-3 py-1 text-muted hover:border-accent hover:text-white">
                {s.label}
              </a>
            ))}
          </div>
        </div>
      </div>
      <p className="border-t border-line py-6 text-center text-xs text-muted">
        © {site.copyrightYear} {site.name}. {t(ui.footer_rights)}
      </p>
    </footer>
  );
}
