import type { Metadata, Viewport } from "next";
import { Inter, Sora, Hind_Siliguri } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/lib/i18n";
import { site } from "@/lib/site-config";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingChat from "@/components/FloatingChat";

const inter = Inter({ variable: "--font-inter", subsets: ["latin"] });
const sora = Sora({ variable: "--font-display-face", subsets: ["latin"], weight: ["600", "700", "800"] });
const bangla = Hind_Siliguri({ variable: "--font-bangla", subsets: ["bengali"], weight: ["400", "500", "600", "700"] });

const description =
  "Ad video production for businesses — product ads, social media reels, promo, explainer, motion graphics and corporate videos. Get a free quote.";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} — Ad Video Production`, template: `%s | ${site.name}` },
  description,
  keywords: [
    "ad video production",
    "product ad video",
    "social media reels",
    "explainer video",
    "motion graphics",
    "corporate video",
    "video editor Bangladesh",
    "বিজ্ঞাপন ভিডিও",
  ],
  openGraph: {
    type: "website",
    siteName: site.name,
    title: `${site.name} — Ad Video Production`,
    description,
    url: "/",
  },
  twitter: { card: "summary_large_image", title: site.name, description },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = { themeColor: "#07070a" };

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className={`${inter.variable} ${sora.variable} ${bangla.variable} antialiased`}>
      <body className="flex min-h-screen flex-col font-sans">
        <LanguageProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
          <FloatingChat />
        </LanguageProvider>
      </body>
    </html>
  );
}
