"use client";

import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { stats } from "@/lib/site-config";
import Reveal from "./Reveal";

// ✏️ Edit your story here
const about = {
  p1: {
    en: "I'm a video creator and motion designer helping brands grow with ads people actually want to watch. Over the last five years I've made product ads, reels, explainers and corporate films for startups, restaurants, fashion brands and tech companies.",
    bn: "আমি একজন ভিডিও ক্রিয়েটর ও মোশন ডিজাইনার। এমন অ্যাড বানাই যা মানুষ সত্যিই দেখতে চায়, আর এর মাধ্যমে ব্র্যান্ডগুলোকে বড় হতে সাহায্য করি। গত পাঁচ বছরে স্টার্টআপ, রেস্টুরেন্ট, ফ্যাশন ব্র্যান্ড ও টেক কোম্পানির জন্য প্রোডাক্ট অ্যাড, রিলস, এক্সপ্লেইনার আর কর্পোরেট ভিডিও বানিয়েছি।",
  },
  p2: {
    en: "Every project starts with your goal — more sales, more followers, or a clearer message. Then I handle everything: script, shoot or animation, edit, sound and color, delivered in every format you need.",
    bn: "প্রতিটা প্রজেক্ট শুরু হয় আপনার লক্ষ্য দিয়ে — বেশি বিক্রি, বেশি ফলোয়ার, অথবা পরিষ্কার মেসেজ। এরপর স্ক্রিপ্ট, শুটিং বা অ্যানিমেশন, এডিট, সাউন্ড আর কালার — সব আমি করি, আর প্রয়োজনীয় সব ফরম্যাটে ডেলিভারি দিই।",
  },
  toolsTitle: { en: "Tools I use", bn: "যেসব টুল ব্যবহার করি" },
};

const tools = ["Premiere Pro", "After Effects", "DaVinci Resolve", "Blender", "Photoshop", "CapCut"];

export default function AboutContent() {
  const { t } = useLang();
  return (
    <section className="mx-auto grid max-w-7xl gap-14 px-5 py-20 lg:grid-cols-[2fr_3fr]">
      <Reveal>
        {/* Replace with your photo: put me.jpg in /public and use <img src="/me.jpg" ... /> */}
        <div className="grain relative aspect-[4/5] overflow-hidden rounded-3xl bg-gradient-to-br from-accent via-rose-600 to-purple-800">
          <span className="absolute inset-0 grid place-items-center text-8xl">🎬</span>
        </div>
      </Reveal>
      <Reveal delay={100}>
        <h2 className="font-display text-3xl font-extrabold leading-tight sm:text-5xl">{t(ui.about_title)}</h2>
        <p className="mt-6 text-lg leading-relaxed text-white/80">{t(about.p1)}</p>
        <p className="mt-4 text-lg leading-relaxed text-white/80">{t(about.p2)}</p>
        <dl className="mt-10 grid grid-cols-2 gap-6 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.value}>
              <dd className="font-display text-3xl font-extrabold text-gradient">{s.value}</dd>
              <dt className="text-sm text-muted">{t(s.label)}</dt>
            </div>
          ))}
        </dl>
        <h3 className="mt-10 font-semibold">{t(about.toolsTitle)}</h3>
        <div className="mt-3 flex flex-wrap gap-2">
          {tools.map((x) => (
            <span key={x} className="rounded-full border border-line px-4 py-1.5 text-sm text-muted">{x}</span>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
