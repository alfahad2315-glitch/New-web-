"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import type { Lead, LeadStatus } from "@/lib/leads";

const STATUS: Record<LeadStatus, { label: string; cls: string }> = {
  new: { label: "New", cls: "bg-sky-500/15 text-sky-300 border-sky-500/40" },
  in_progress: { label: "In Progress", cls: "bg-amber-500/15 text-amber-300 border-amber-500/40" },
  done: { label: "Done", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40" },
};

export default function AdminDashboard() {
  const [state, setState] = useState<"loading" | "login" | "ready">("loading");
  const [leads, setLeads] = useState<Lead[]>([]);
  const [dbConfigured, setDbConfigured] = useState(true);
  const [filter, setFilter] = useState<LeadStatus | "all">("all");
  const [open, setOpen] = useState<string | null>(null);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    const res = await fetch("/api/admin/leads", { cache: "no-store" });
    if (res.status === 401) return setState("login");
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Failed to load leads");
      return setState("ready");
    }
    setLeads(json.leads);
    setDbConfigured(json.dbConfigured);
    setState("ready");
  }, []);

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initial data fetch
    load();
  }, [load]);

  async function setStatus(id: string, status: LeadStatus) {
    setLeads((ls) => ls.map((l) => (l.id === id ? { ...l, status } : l)));
    const res = await fetch("/api/admin/leads", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    if (!res.ok) {
      setError("Could not update status");
      load();
    }
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    setState("login");
  }

  const counts = useMemo(
    () => ({
      all: leads.length,
      new: leads.filter((l) => l.status === "new").length,
      in_progress: leads.filter((l) => l.status === "in_progress").length,
      done: leads.filter((l) => l.status === "done").length,
    }),
    [leads],
  );

  if (state === "loading") return <p className="p-10 text-muted">Loading…</p>;
  if (state === "login") return <Login onDone={load} />;

  const shown = filter === "all" ? leads : leads.filter((l) => l.status === filter);

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-3xl font-extrabold">Leads</h1>
        <div className="flex gap-2">
          <button onClick={load} className="rounded-full border border-line px-4 py-2 text-sm hover:border-white">↻ Refresh</button>
          <button onClick={logout} className="rounded-full border border-line px-4 py-2 text-sm hover:border-white">Log out</button>
        </div>
      </div>

      {!dbConfigured && (
        <p className="mt-6 rounded-xl border border-amber-500/40 bg-amber-500/10 p-4 text-sm text-amber-200">
          ⚠️ Supabase is not configured — leads are kept in memory only and will disappear when the server restarts.
          Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY (see README).
        </p>
      )}
      {error && <p className="mt-6 rounded-xl border border-red-500/40 bg-red-500/10 p-4 text-sm text-red-200">{error}</p>}

      <div className="mt-8 flex flex-wrap gap-2">
        {(["all", "new", "in_progress", "done"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`rounded-full border px-4 py-2 text-sm ${filter === s ? "border-accent bg-accent text-black font-semibold" : "border-line text-muted hover:text-white"}`}
          >
            {s === "all" ? "All" : STATUS[s].label} ({counts[s]})
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-3">
        {shown.length === 0 && <p className="py-10 text-center text-muted">No leads yet.</p>}
        {shown.map((l) => (
          <div key={l.id} className="rounded-2xl border border-line bg-panel">
            <div className="flex flex-wrap items-center gap-4 p-5">
              <button onClick={() => setOpen(open === l.id ? null : l.id)} className="min-w-0 flex-1 text-left">
                <p className="truncate font-semibold">{l.company} <span className="font-normal text-muted">· {l.contact_name}</span></p>
                <p className="text-sm text-muted">
                  {l.video_type}
                  {l.budget ? ` · ${l.budget}` : ""} · {new Date(l.created_at).toLocaleString()}
                </p>
              </button>
              <select
                value={l.status}
                onChange={(e) => setStatus(l.id, e.target.value as LeadStatus)}
                className={`rounded-full border px-3 py-1.5 text-sm ${STATUS[l.status].cls}`}
                aria-label="Status"
              >
                {(Object.keys(STATUS) as LeadStatus[]).map((s) => (
                  <option key={s} value={s} className="bg-panel text-white">{STATUS[s].label}</option>
                ))}
              </select>
            </div>
            {open === l.id && (
              <dl className="grid gap-x-6 gap-y-3 border-t border-line p-5 text-sm sm:grid-cols-2">
                <Item k="Phone / WhatsApp">
                  <a className="text-accent" href={`https://wa.me/${l.phone.replace(/\D/g, "")}`} target="_blank" rel="noopener">{l.phone}</a>
                </Item>
                <Item k="Email"><a className="text-accent" href={`mailto:${l.email}`}>{l.email}</a></Item>
                <Item k="Length">{l.length}</Item>
                <Item k="Deadline">{l.deadline}</Item>
                <Item k="Package">{l.package}</Item>
                <Item k="Attachment">
                  {l.file_url ? <a className="text-accent" href={l.file_url} target="_blank" rel="noopener">Download file</a> : l.file_path ? "Uploaded" : null}
                </Item>
                <Item k="References" wide>{l.reference_links}</Item>
                <Item k="Details" wide>{l.details}</Item>
              </dl>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

function Item({ k, children, wide }: { k: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className={wide ? "sm:col-span-2" : ""}>
      <dt className="text-muted">{k}</dt>
      <dd className="whitespace-pre-wrap break-words">{children || "—"}</dd>
    </div>
  );
}

function Login({ onDone }: { onDone: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const res = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password: pw }),
    });
    setBusy(false);
    if (res.ok) return onDone();
    const json = await res.json().catch(() => ({}));
    setErr(json.error || "Login failed");
  }

  return (
    <div className="grid min-h-screen place-items-center px-5">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-line bg-panel p-8">
        <h1 className="font-display text-2xl font-extrabold">Admin login</h1>
        <input
          type="password"
          value={pw}
          onChange={(e) => setPw(e.target.value)}
          placeholder="Password"
          className="field mt-6"
          autoFocus
          required
        />
        {err && <p className="mt-3 text-sm text-red-400">{err}</p>}
        <button disabled={busy} className="mt-5 w-full rounded-full bg-accent py-3 font-semibold text-black disabled:opacity-60">
          {busy ? "…" : "Log in"}
        </button>
      </form>
    </div>
  );
}
