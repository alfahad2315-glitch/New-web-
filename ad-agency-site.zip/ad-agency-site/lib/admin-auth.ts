// Very simple password login for the admin page (one admin = you).
import { createHmac, timingSafeEqual } from "node:crypto";
import type { NextRequest } from "next/server";

export const ADMIN_COOKIE = "admin_session";

function expectedToken() {
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw || pw.length < 8) return null; // admin disabled until a strong password is set
  return createHmac("sha256", pw).update("admin-session-v1").digest("hex");
}

function safeEqual(a: string, b: string) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export function checkPassword(password: string) {
  const pw = process.env.ADMIN_PASSWORD;
  return !!pw && pw.length >= 8 && safeEqual(password, pw);
}

export function sessionToken() {
  return expectedToken();
}

export function isAdmin(req: NextRequest) {
  const token = expectedToken();
  const cookie = req.cookies.get(ADMIN_COOKIE)?.value;
  return !!token && !!cookie && safeEqual(cookie, token);
}
