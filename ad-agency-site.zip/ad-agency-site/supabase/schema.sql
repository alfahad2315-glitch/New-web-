-- Run this once in Supabase → SQL Editor → New query → Run

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  company text not null,
  contact_name text not null,
  phone text not null,
  email text not null,
  video_type text not null,
  length text,
  budget text,
  deadline date,
  package text,
  reference_links text,
  details text,
  file_path text,
  status text not null default 'new' check (status in ('new', 'in_progress', 'done'))
);

create index if not exists leads_created_at_idx on public.leads (created_at desc);

-- Lock the table: only the server (service role key) can read/write it.
alter table public.leads enable row level security;

-- Private storage bucket for uploaded briefs / logos
insert into storage.buckets (id, name, public)
values ('briefs', 'briefs', false)
on conflict (id) do nothing;
