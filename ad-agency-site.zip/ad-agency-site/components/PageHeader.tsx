"use client";

import type { T } from "@/lib/site-config";
import { useLang } from "@/lib/i18n";

export default function PageHeader({ title, sub }: { title: T; sub?: T }) {
  const { t } = useLang();
  return (
    <header className="relative overflow-hidden border-b border-line pb-14 pt-36">
      <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[40rem] -translate-x-1/2 rounded-full bg-accent/20 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-5">
        <h1 className="font-display text-4xl font-extrabold tracking-tight sm:text-6xl">{t(title)}</h1>
        {sub && <p className="mt-4 max-w-2xl text-lg text-muted">{t(sub)}</p>}
      </div>
    </header>
  );
}
