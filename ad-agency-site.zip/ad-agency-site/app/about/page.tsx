import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import AboutContent from "@/components/AboutContent";
import { CTA, Testimonials } from "@/components/sections";
import { ui } from "@/lib/ui";

export const metadata: Metadata = {
  title: "About",
  description: "Video creator and motion designer making ad videos that grow brands.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <>
      <PageHeader title={ui.nav_about} />
      <AboutContent />
      <Testimonials />
      <CTA />
    </>
  );
}
