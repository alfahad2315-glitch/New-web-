# 🎬 Ad Video Agency Website — সেটআপ গাইড (বিগিনারদের জন্য)

Next.js + TypeScript + Tailwind CSS দিয়ে বানানো আপনার পোর্টফোলিও ও এজেন্সি ওয়েবসাইট।
লিড সেভ হয় Supabase-এ, ইমেইল যায় Resend দিয়ে, আর সাইট লাইভ হয় Vercel-এ।

## কী কী আছে

| পেজ | ঠিকানা |
|---|---|
| হোম (শোরিল, ক্লায়েন্ট লোগো, কাজ, রিভিউ) | `/` |
| পোর্টফোলিও (ফিল্টার + ভিডিও পপআপ) | `/portfolio` |
| সার্ভিস ও মূল্য (৩টি প্যাকেজ, BDT + USD) | `/services` |
| আমার সম্পর্কে | `/about` |
| প্রশ্নোত্তর | `/faq` |
| কোট ফর্ম (ফাইল আপলোডসহ) | `/contact` |
| অ্যাডমিন (লিড দেখা, New / In Progress / Done) | `/admin` |

সাথে আরও আছে: বাংলা/ইংরেজি টগল, WhatsApp ও Messenger বাটন, ফ্রি কল বুকিং লিংক, sitemap.xml, robots.txt, শেয়ার ইমেজ (Open Graph) আর স্ক্রল অ্যানিমেশন।

---

## ধাপ ১ — নিজের তথ্য বসান ✏️

প্রায় সব লেখা একটা ফাইলেই আছে: **`lib/site-config.ts`**

- `site` অংশে: নাম, ইমেইল, WhatsApp নম্বর (যেমন `8801712345678`), Messenger পেজের নাম, সোশ্যাল লিংক, বুকিং লিংক
- `showreelMp4`: হোম পেজের ব্যাকগ্রাউন্ড ভিডিও। ১০–৩০ সেকেন্ডের একটা ছোট MP4 (১০ MB-এর কম) `public/showreel.mp4` নামে রাখুন, তারপর এখানে লিখুন `"/showreel.mp4"`
- `works`: আপনার ভিডিওগুলো। YouTube লিংক `youtube.com/watch?v=ABC123` হলে `videoId: "ABC123"`
  - থাম্বনেইল দেখাতে লিখুন: `thumbnail: "https://img.youtube.com/vi/ABC123/hqdefault.jpg"`
  - রিলস হলে `vertical: true`, হোম পেজে দেখাতে চাইলে `featured: true`
- `packages`: প্যাকেজের দাম আর সুবিধা
- `testimonials`, `faqs`, `clients`, `stats`: রিভিউ, প্রশ্নোত্তর, ক্লায়েন্ট আর পরিসংখ্যান

> ⚠️ এখন যে ভিডিও, ক্লায়েন্টের নাম আর রিভিউগুলো আছে সেগুলো শুধু নমুনা। সাইট লাইভ করার আগে অবশ্যই নিজের আসল তথ্য দিয়ে বদলে দিন।

"আমার সম্পর্কে" পেজের লেখা আছে `components/AboutContent.tsx`-এ, আর বাটন বা মেনুর লেখা আছে `lib/ui.ts`-এ।

---

## ধাপ ২ — কম্পিউটারে চালিয়ে দেখুন

১. [Node.js](https://nodejs.org) (LTS) ইনস্টল করুন।
২. প্রজেক্ট ফোল্ডারে টার্মিনাল খুলে চালান:

```bash
npm install
```

```bash
cp .env.example .env.local
```

```bash
npm run dev
```

৩. ব্রাউজারে খুলুন http://localhost:3000

Supabase সেটআপ না করলেও ফর্ম কাজ করবে। তবে তখন লিডগুলো শুধু মেমোরিতে থাকে, সার্ভার বন্ধ করলে মুছে যায়। অ্যাডমিন পেজ টেস্ট করতে `.env.local`-এ `ADMIN_PASSWORD=` দিয়ে অন্তত ৮ অক্ষরের একটা পাসওয়ার্ড দিন।

---

## ধাপ ৩ — Supabase (লিড সেভ করার ডাটাবেস)

১. https://supabase.com এ ফ্রি অ্যাকাউন্ট খুলে **New project** তৈরি করুন।
২. বাম মেনু থেকে **SQL Editor → New query**। `supabase/schema.sql` ফাইলের সব লেখা কপি করে পেস্ট করুন, তারপর **Run** চাপুন। এতে `leads` টেবিল আর ফাইল রাখার জন্য প্রাইভেট `briefs` বাকেট তৈরি হবে।
৩. **Project Settings → API** থেকে এই দুটো কপি করে `.env.local`-এ বসান:
   - Project URL যাবে `SUPABASE_URL`-এ
   - `service_role` key যাবে `SUPABASE_SERVICE_ROLE_KEY`-এ (🔒 এটা গোপন রাখুন, কারো সাথে শেয়ার করবেন না)

---

## ধাপ ৪ — Resend (নতুন লিডের ইমেইল)

১. https://resend.com এ অ্যাকাউন্ট খুলে **API Keys → Create** করুন।
২. `.env.local`-এ বসান:
   - `RESEND_API_KEY=` আপনার key
   - `LEADS_EMAIL_TO=` যে ইমেইলে লিড পেতে চান
৩. শুরুতে `onboarding@resend.dev` থেকে শুধু আপনার নিজের (Resend অ্যাকাউন্টের) ইমেইলে মেইল যাবে। পরে নিজের ডোমেইন verify করে `LEADS_EMAIL_FROM` বদলে দিন, যেমন `Leads <hello@yourdomain.com>`।

---

## ধাপ ৫ — Vercel-এ লাইভ করুন 🚀

১. কোডটা GitHub-এ একটা নতুন repository-তে আপলোড করুন।
২. https://vercel.com এ GitHub দিয়ে লগইন করে **Add New → Project** থেকে repo-টা Import করুন।
৩. **Environment Variables**-এ `.env.example`-এর সব নাম আর মান বসান। `NEXT_PUBLIC_SITE_URL`-এ দিন আপনার লাইভ ঠিকানা (যেমন `https://yourname.vercel.app`)।
৪. **Deploy** চাপুন। কয়েক মিনিটের মধ্যে সাইট লাইভ হয়ে যাবে।
৫. নিজের ডোমেইন থাকলে: **Settings → Domains**-এ যোগ করুন।

এরপর কোডে কিছু বদলে GitHub-এ push করলেই Vercel নিজে থেকে সাইট আপডেট করবে।

---

## ধাপ ৬ — Google-এ খুঁজে পাওয়ার জন্য (SEO)

- https://search.google.com/search-console এ সাইট যোগ করুন, তারপর `https://আপনার-সাইট/sitemap.xml` সাবমিট করুন।
- লিংক শেয়ার করলে যে ছবি দেখায় সেটা `app/opengraph-image.tsx`-এ তৈরি হয়। চাইলে নিজের মতো বদলে নিন।

---

## ফাইলগুলো কোথায়

```
lib/site-config.ts     ← আপনার সব তথ্য (সবচেয়ে বেশি এটাই এডিট করবেন)
lib/ui.ts              ← বাটন ও মেনুর বাংলা/ইংরেজি লেখা
components/            ← পেজের অংশগুলো (Hero, QuoteForm, AdminDashboard …)
app/                   ← পেজ ও API (app/api/quote = ফর্ম জমা, app/api/admin = অ্যাডমিন)
supabase/schema.sql    ← ডাটাবেস টেবিল
.env.example           ← কোন কোন গোপন key লাগবে তার তালিকা
```

## নিরাপত্তা নোট

- `.env.local` কখনো GitHub-এ আপলোড করবেন না (এটা `.gitignore`-এ দেওয়া আছে)।
- `/admin` পেজ শুধু পাসওয়ার্ড দিয়ে খোলে। ৫ বার ভুল পাসওয়ার্ড দিলে ১৫ মিনিট লক থাকে।
- ফর্মে স্প্যাম ঠেকাতে honeypot আর rate limit আছে। আপলোড ফাইলের সর্বোচ্চ সাইজ ৪ MB (Vercel-এর সীমার কারণে)।
