"use client";

import { categories, type Work } from "@/lib/site-config";
import { useLang } from "@/lib/i18n";

export default function WorkCard({ work, onPlay }: { work: Work; onPlay: () => void }) {
  const { t } = useLang();
  const cat = categories.find((c) => c.id === work.category);

  return (
    <button
      onClick={onPlay}
      className="group relative block w-full overflow-hidden rounded-2xl border border-line bg-panel text-left"
    >
      <div className="relative aspect-video overflow-hidden">
        {work.thumbnail ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={work.thumbnail}
            alt={t(work.title)}
            loading="lazy"
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
        ) : (
          <div className={`grain relative h-full w-full bg-gradient-to-br ${work.gradient} transition duration-700 group-hover:scale-105`}>
            <span className="absolute bottom-3 left-4 font-display text-4xl font-extrabold text-white/15">
              {work.client}
            </span>
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/0 to-black/0" />
        <span className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-black shadow-xl transition duration-300 group-hover:scale-110 group-hover:bg-accent">
          <svg viewBox="0 0 24 24" className="ml-1 h-7 w-7 fill-current" aria-hidden>
            <path d="M8 5v14l11-7z" />
          </svg>
        </span>
        {work.vertical && (
          <span className="absolute right-3 top-3 rounded-full bg-black/60 px-2 py-0.5 text-[11px] text-white">9:16</span>
        )}
      </div>
      <div className="flex items-center justify-between gap-3 p-4">
        <div>
          <p className="font-semibold">{t(work.title)}</p>
          <p className="text-sm text-muted">{work.client}</p>
        </div>
        {cat && <span className="shrink-0 rounded-full border border-line px-3 py-1 text-xs text-muted">{t(cat.label)}</span>}
      </div>
    </button>
  );
}
