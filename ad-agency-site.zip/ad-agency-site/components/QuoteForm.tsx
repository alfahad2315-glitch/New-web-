"use client";

import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { budgetRanges, lengths, packages, site, videoTypes } from "@/lib/site-config";

const MAX_FILE = 4 * 1024 * 1024;

export default function QuoteForm() {
  const { t } = useLang();
  const [status, setStatus] = useState<"idle" | "sending" | "done" | "error">("idle");
  const [error, setError] = useState("");
  const [pkg, setPkg] = useState("");

  // Pre-select a package when coming from the pricing page (/contact?package=standard)
  useEffect(() => {
    const p = new URLSearchParams(window.location.search).get("package");
    // eslint-disable-next-line react-hooks/set-state-in-effect -- read once from the URL on mount
    if (p && packages.some((x) => x.id === p)) setPkg(p);
  }, []);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = new FormData(form);
    const file = data.get("file");
    if (file instanceof File && file.size > MAX_FILE) {
      setError(t(ui.f_file_big));
      setStatus("error");
      return;
    }
    setStatus("sending");
    setError("");
    try {
      const res = await fetch("/api/quote", { method: "POST", body: data });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json.error || "failed");
      setStatus("done");
      form.reset();
    } catch (err) {
      setError(err instanceof Error && err.message !== "failed" ? err.message : t(ui.f_error));
      setStatus("error");
    }
  }

  if (status === "done") {
    return (
      <div className="rounded-3xl border border-accent/50 bg-accent/10 p-10 text-center">
        <p className="text-5xl">🎉</p>
        <p className="mt-4 text-xl font-semibold">{t(ui.f_success)}</p>
        <a
          href={`https://wa.me/${site.whatsapp}`}
          target="_blank"
          rel="noopener"
          className="mt-6 inline-block rounded-full bg-[#25D366] px-6 py-3 font-semibold text-black"
        >
          {t(ui.chat_whatsapp)}
        </a>
      </div>
    );
  }

  const label = "mb-2 block text-sm font-medium text-white/85";

  return (
    <form onSubmit={onSubmit} className="grid gap-5 rounded-3xl border border-line bg-panel/60 p-6 sm:grid-cols-2 sm:p-8">
      {/* Honeypot field: hidden from humans, bots fill it in */}
      <input type="text" name="website" tabIndex={-1} autoComplete="off" className="hidden" aria-hidden />

      <div>
        <label className={label} htmlFor="company">{t(ui.f_company)} *</label>
        <input id="company" name="company" required maxLength={120} className="field" />
      </div>
      <div>
        <label className={label} htmlFor="contact_name">{t(ui.f_contact)} *</label>
        <input id="contact_name" name="contact_name" required maxLength={120} className="field" />
      </div>
      <div>
        <label className={label} htmlFor="phone">{t(ui.f_phone)} *</label>
        <input id="phone" name="phone" type="tel" required maxLength={30} placeholder="+8801…" className="field" />
      </div>
      <div>
        <label className={label} htmlFor="email">{t(ui.f_email)} *</label>
        <input id="email" name="email" type="email" required maxLength={160} className="field" />
      </div>
      <div>
        <label className={label} htmlFor="video_type">{t(ui.f_type)} *</label>
        <select id="video_type" name="video_type" required className="field" defaultValue="">
          <option value="" disabled>{t(ui.f_select)}</option>
          {videoTypes.map((v) => (
            <option key={v.id} value={v.label.en}>{t(v.label)}</option>
          ))}
        </select>
      </div>
      <div>
        <label className={label} htmlFor="length">{t(ui.f_length)}</label>
        <select id="length" name="length" className="field" defaultValue="">
          <option value="">{t(ui.f_select)}</option>
          {lengths.map((v) => (
            <option key={v.en} value={v.en}>{t(v)}</option>
          ))}
        </select>
      </div>
      <div>
        <label className={label} htmlFor="budget">{t(ui.f_budget)}</label>
        <select id="budget" name="budget" className="field" defaultValue="">
          <option value="">{t(ui.f_select)}</option>
          {budgetRanges.map((v) => (
            <option key={v.en} value={v.en}>{t(v)}</option>
          ))}
        </select>
      </div>
      <div>
        <label className={label} htmlFor="deadline">{t(ui.f_deadline)}</label>
        <input id="deadline" name="deadline" type="date" className="field [color-scheme:dark]" />
      </div>
      <div className="sm:col-span-2">
        <label className={label} htmlFor="package">{t(ui.f_package)}</label>
        <select id="package" name="package" className="field" value={pkg} onChange={(e) => setPkg(e.target.value)}>
          <option value="">{t(ui.f_select)}</option>
          {packages.map((p) => (
            <option key={p.id} value={p.id}>{t(p.name)} — ৳{p.bdt} / ${p.usd}</option>
          ))}
        </select>
      </div>
      <div className="sm:col-span-2">
        <label className={label} htmlFor="reference_links">{t(ui.f_refs)}</label>
        <textarea id="reference_links" name="reference_links" rows={2} maxLength={1000} placeholder="https://…" className="field" />
      </div>
      <div className="sm:col-span-2">
        <label className={label} htmlFor="details">{t(ui.f_details)}</label>
        <textarea id="details" name="details" rows={4} maxLength={3000} className="field" />
      </div>
      <div className="sm:col-span-2">
        <label className={label} htmlFor="file">{t(ui.f_file)}</label>
        <input
          id="file"
          name="file"
          type="file"
          accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.svg,.ai,.zip"
          className="field file:mr-4 file:rounded-full file:border-0 file:bg-white file:px-4 file:py-1.5 file:text-sm file:font-semibold file:text-black"
        />
      </div>

      {status === "error" && <p className="text-sm text-red-400 sm:col-span-2" role="alert">{error}</p>}

      <button
        type="submit"
        disabled={status === "sending"}
        className="rounded-full bg-accent py-4 font-semibold text-black transition hover:brightness-110 disabled:opacity-60 sm:col-span-2"
      >
        {status === "sending" ? t(ui.f_sending) : `${t(ui.f_submit)} →`}
      </button>
    </form>
  );
}
