"use client";

import Link from "next/link";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { faqs, packages, services, site, steps, testimonials, works, type Work } from "@/lib/site-config";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";
import WorkCard from "./WorkCard";
import VideoLightbox, { type LightboxVideo } from "./VideoLightbox";

export function ServicesGrid() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <SectionHeading kicker={ui.what_i_do} title={ui.services_title} />
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((s, i) => (
          <Reveal key={s.title.en} delay={i * 70}>
            <div className="h-full rounded-2xl border border-line bg-panel p-7 transition hover:-translate-y-1 hover:border-accent/60">
              <span className="text-3xl">{s.icon}</span>
              <h3 className="mt-4 text-xl font-semibold">{t(s.title)}</h3>
              <p className="mt-2 text-muted">{t(s.desc)}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function WorkGrid({ items, columns = "sm:grid-cols-2 lg:grid-cols-3" }: { items: Work[]; columns?: string }) {
  const { t } = useLang();
  const [active, setActive] = useState<LightboxVideo | null>(null);
  return (
    <>
      <div className={`grid items-start gap-5 ${columns}`}>
        {items.map((w, i) => (
          <Reveal key={`${w.title.en}-${i}`} delay={(i % 3) * 80}>
            <WorkCard work={w} onPlay={() => setActive({ ...w, title: t(w.title) })} />
          </Reveal>
        ))}
      </div>
      <VideoLightbox video={active} onClose={() => setActive(null)} />
    </>
  );
}

export function FeaturedWork() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHeading kicker={ui.featured_work} title={ui.featured_title} />
        <Link href="/portfolio" className="mb-12 text-sm font-semibold text-accent hover:underline">
          {t(ui.view_all)} →
        </Link>
      </div>
      <WorkGrid items={works.filter((w) => w.featured).slice(0, 6)} />
    </section>
  );
}

export function Pricing() {
  const { t, lang } = useLang();
  const fmt = (n: number) => n.toLocaleString(lang === "bn" ? "bn-BD" : "en-US");
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <SectionHeading title={ui.pricing_title} sub={ui.pricing_sub} center />
      <div className="grid gap-6 lg:grid-cols-3">
        {packages.map((p, i) => (
          <Reveal key={p.id} delay={i * 90}>
            <div
              className={`relative flex h-full flex-col rounded-3xl border p-8 ${
                p.popular ? "border-accent bg-gradient-to-b from-accent/15 to-panel" : "border-line bg-panel"
              }`}
            >
              {p.popular && (
                <span className="absolute -top-3 left-8 rounded-full bg-accent px-3 py-1 text-xs font-bold text-black">
                  {t(ui.most_popular)}
                </span>
              )}
              <h3 className="text-lg font-semibold">{t(p.name)}</h3>
              <p className="mt-4 font-display text-4xl font-extrabold">৳{fmt(p.bdt)}</p>
              <p className="text-sm text-muted">≈ ${fmt(p.usd)} USD</p>
              <ul className="mt-6 flex-1 space-y-3">
                {p.features.map((f) => (
                  <li key={f.en} className="flex gap-3 text-sm">
                    <span className="text-accent">✓</span>
                    <span>{t(f)}</span>
                  </li>
                ))}
              </ul>
              <Link
                href={`/contact?package=${p.id}`}
                className={`mt-8 block rounded-full py-3 text-center font-semibold transition ${
                  p.popular ? "bg-accent text-black hover:brightness-110" : "border border-line hover:border-white"
                }`}
              >
                {t(ui.choose)} {t(p.name)}
              </Link>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function HowItWorks() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <SectionHeading kicker={ui.how_it_works} title={ui.how_title} />
      <ol className="grid gap-5 md:grid-cols-5">
        {steps.map((s, i) => (
          <Reveal key={s.title.en} delay={i * 80}>
            <li className="relative h-full rounded-2xl border border-line bg-panel p-6">
              <span className="font-display text-5xl font-extrabold text-gradient">0{i + 1}</span>
              <h3 className="mt-3 text-lg font-semibold">{t(s.title)}</h3>
              <p className="mt-2 text-sm text-muted">{t(s.desc)}</p>
              {i < steps.length - 1 && (
                <span className="absolute -right-4 top-1/2 hidden -translate-y-1/2 text-xl text-line md:block">→</span>
              )}
            </li>
          </Reveal>
        ))}
      </ol>
    </section>
  );
}

export function Testimonials() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <SectionHeading kicker={ui.testimonials} title={ui.testimonials_title} />
      <div className="grid gap-5 md:grid-cols-3">
        {testimonials.map((x, i) => (
          <Reveal key={x.name} delay={i * 90}>
            <figure className="flex h-full flex-col rounded-2xl border border-line bg-panel p-7">
              <p className="text-accent">★★★★★</p>
              <blockquote className="mt-4 flex-1 text-lg leading-relaxed">“{t(x.quote)}”</blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-accent to-accent-2 font-bold text-black">
                  {x.name[0]}
                </span>
                <span>
                  <span className="block font-semibold">{x.name}</span>
                  <span className="block text-sm text-muted">{t(x.role)}</span>
                </span>
              </figcaption>
            </figure>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function FaqList() {
  const { t } = useLang();
  return (
    <div className="mx-auto max-w-3xl divide-y divide-line rounded-2xl border border-line bg-panel">
      {faqs.map((f) => (
        <details key={f.q.en} className="group p-6">
          <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-lg font-semibold">
            {t(f.q)}
            <span className="text-2xl text-accent transition group-open:rotate-45">+</span>
          </summary>
          <p className="mt-3 text-muted">{t(f.a)}</p>
        </details>
      ))}
    </div>
  );
}

export function CTA() {
  const { t } = useLang();
  return (
    <section className="mx-auto max-w-7xl px-5 py-24">
      <Reveal>
        <div className="grain relative overflow-hidden rounded-3xl bg-gradient-to-br from-accent to-accent-2 p-10 text-black sm:p-16">
          <h2 className="max-w-2xl font-display text-3xl font-extrabold leading-tight sm:text-5xl">{t(ui.cta_title)}</h2>
          <p className="mt-4 max-w-xl text-lg text-black/75">{t(ui.cta_sub)}</p>
          <div className="relative z-10 mt-8 flex flex-wrap gap-3">
            <Link href="/contact" className="rounded-full bg-black px-7 py-3 font-semibold text-white hover:bg-black/80">
              {t(ui.get_quote)}
            </Link>
            {site.bookingUrl && (
              <a href={site.bookingUrl} target="_blank" rel="noopener" className="rounded-full border border-black/30 px-7 py-3 font-semibold hover:bg-black/10">
                📅 {t(ui.book_call)}
              </a>
            )}
          </div>
        </div>
      </Reveal>
    </section>
  );
}
