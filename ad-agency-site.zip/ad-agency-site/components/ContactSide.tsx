"use client";

import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { site } from "@/lib/site-config";

export default function ContactSide() {
  const { t } = useLang();
  const items = [
    { icon: "💬", label: t(ui.chat_whatsapp), value: `+${site.whatsapp}`, href: `https://wa.me/${site.whatsapp}` },
    { icon: "📨", label: t(ui.chat_messenger), value: `m.me/${site.messenger}`, href: `https://m.me/${site.messenger}` },
    { icon: "✉️", label: t(ui.f_email), value: site.email, href: `mailto:${site.email}` },
  ];
  return (
    <aside className="space-y-4">
      {items.map((i) => (
        <a key={i.label} href={i.href} target="_blank" rel="noopener" className="flex items-center gap-4 rounded-2xl border border-line bg-panel p-5 transition hover:border-accent">
          <span className="text-2xl">{i.icon}</span>
          <span>
            <span className="block text-sm text-muted">{i.label}</span>
            <span className="block font-semibold">{i.value}</span>
          </span>
        </a>
      ))}
      {site.bookingUrl && (
        <a href={site.bookingUrl} target="_blank" rel="noopener" className="block rounded-2xl bg-gradient-to-br from-accent to-accent-2 p-6 text-black">
          <span className="text-2xl">📅</span>
          <span className="mt-2 block text-lg font-bold">{t(ui.book_call)}</span>
          <span className="block text-sm text-black/70">15–30 min · Google Meet / Zoom</span>
        </a>
      )}
    </aside>
  );
}
