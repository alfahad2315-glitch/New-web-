import { NextResponse, type NextRequest } from "next/server";
import { insertLead, uploadBrief, type NewLead } from "@/lib/leads";
import { sendLeadEmail } from "@/lib/email";

const MAX_FILE = 4 * 1024 * 1024; // Vercel limits request bodies to ~4.5 MB
const ALLOWED_EXT = /\.(pdf|docx?|txt|png|jpe?g|svg|ai|zip)$/i;

// Basic in-memory rate limit: 5 requests / 10 minutes per IP (per server instance)
const hits = new Map<string, number[]>();
function rateLimited(ip: string) {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < 10 * 60_000);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length > 5;
}

const str = (fd: FormData, key: string, max: number) => {
  const v = fd.get(key);
  return typeof v === "string" ? v.trim().slice(0, max) : "";
};

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
  if (rateLimited(ip)) {
    return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 });
  }

  let fd: FormData;
  try {
    fd = await req.formData();
  } catch {
    return NextResponse.json({ error: "Invalid form data." }, { status: 400 });
  }

  // Honeypot: real users never fill this hidden field
  if (str(fd, "website", 200)) return NextResponse.json({ ok: true });

  const lead: NewLead = {
    company: str(fd, "company", 120),
    contact_name: str(fd, "contact_name", 120),
    phone: str(fd, "phone", 30),
    email: str(fd, "email", 160),
    video_type: str(fd, "video_type", 60),
    length: str(fd, "length", 40) || null,
    budget: str(fd, "budget", 80) || null,
    deadline: str(fd, "deadline", 20) || null,
    package: str(fd, "package", 20) || null,
    reference_links: str(fd, "reference_links", 1000) || null,
    details: str(fd, "details", 3000) || null,
    file_path: null,
  };

  if (!lead.company || !lead.contact_name || !lead.phone || !lead.email || !lead.video_type) {
    return NextResponse.json({ error: "Please fill in all required fields." }, { status: 400 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(lead.email)) {
    return NextResponse.json({ error: "Please enter a valid email address." }, { status: 400 });
  }
  if (!/^\+?[\d\s\-()]{6,30}$/.test(lead.phone)) {
    return NextResponse.json({ error: "Please enter a valid phone number." }, { status: 400 });
  }
  if (lead.deadline && !/^\d{4}-\d{2}-\d{2}$/.test(lead.deadline)) lead.deadline = null;

  try {
    const file = fd.get("file");
    if (file instanceof File && file.size > 0) {
      if (file.size > MAX_FILE) return NextResponse.json({ error: "File is larger than 4 MB." }, { status: 400 });
      if (!ALLOWED_EXT.test(file.name)) return NextResponse.json({ error: "This file type is not allowed." }, { status: 400 });
      lead.file_path = await uploadBrief(file);
    }

    const saved = await insertLead(lead);
    await sendLeadEmail(saved).catch((e) => console.error("[email]", e));
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[quote]", e);
    return NextResponse.json({ error: "Could not save your request. Please message on WhatsApp." }, { status: 500 });
  }
}
