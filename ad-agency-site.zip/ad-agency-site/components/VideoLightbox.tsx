"use client";

import { useEffect } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";

export type LightboxVideo = { platform: "youtube" | "vimeo"; videoId: string; title: string; vertical?: boolean };

export function embedUrl(v: Pick<LightboxVideo, "platform" | "videoId">) {
  return v.platform === "vimeo"
    ? `https://player.vimeo.com/video/${v.videoId}?autoplay=1&title=0&byline=0`
    : `https://www.youtube-nocookie.com/embed/${v.videoId}?autoplay=1&rel=0&modestbranding=1`;
}

export default function VideoLightbox({ video, onClose }: { video: LightboxVideo | null; onClose: () => void }) {
  const { t } = useLang();

  useEffect(() => {
    if (!video) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [video, onClose]);

  if (!video) return null;

  return (
    <div
      className="fixed inset-0 z-50 grid place-items-center bg-black/90 p-4 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={video.title}
    >
      <button
        onClick={onClose}
        className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/20 text-xl text-white hover:bg-white/10"
        aria-label={t(ui.close)}
      >
        ✕
      </button>
      <div
        className={`w-full overflow-hidden rounded-2xl bg-black shadow-2xl ${
          video.vertical ? "aspect-[9/16] max-h-[85vh] max-w-[min(420px,calc(85vh*9/16))]" : "aspect-video max-w-5xl"
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        <iframe
          src={embedUrl(video)}
          title={video.title}
          className="h-full w-full"
          allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
          allowFullScreen
        />
      </div>
    </div>
  );
}
