import type { Metadata } from "next";
import PageHeader from "@/components/PageHeader";
import QuoteForm from "@/components/QuoteForm";
import ContactSide from "@/components/ContactSide";
import { ui } from "@/lib/ui";

export const metadata: Metadata = {
  title: "Get a Quote",
  description: "Tell me about your ad video project and get a free quote within 24 hours.",
  alternates: { canonical: "/contact" },
};

export default function ContactPage() {
  return (
    <>
      <PageHeader title={ui.contact_title} sub={ui.contact_sub} />
      <section className="mx-auto grid max-w-7xl gap-10 px-5 py-16 lg:grid-cols-[2fr_1fr]">
        <QuoteForm />
        <ContactSide />
      </section>
    </>
  );
}
