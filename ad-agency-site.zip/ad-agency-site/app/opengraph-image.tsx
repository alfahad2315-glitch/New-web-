import { ImageResponse } from "next/og";
import { site } from "@/lib/site-config";

// Auto-generated social share image (shown when your link is shared on Facebook, WhatsApp, etc.)
export const alt = `${site.name} — Ad Video Production`;
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: 72,
          background: "linear-gradient(135deg, #07070a 0%, #1a0d08 60%, #ff5a1f 140%)",
          color: "white",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 16, fontSize: 32, fontWeight: 700 }}>
          <div style={{ width: 22, height: 22, borderRadius: 11, background: "#ff5a1f" }} />
          {site.name}
        </div>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <div style={{ fontSize: 96, fontWeight: 800, lineHeight: 1.02, letterSpacing: -3 }}>Ads that stop</div>
          <div style={{ fontSize: 96, fontWeight: 800, lineHeight: 1.02, letterSpacing: -3, color: "#ffb21f" }}>
            the scroll.
          </div>
        </div>
        <div style={{ fontSize: 30, color: "#b5b5c3" }}>
          Product Ads · Reels · Explainers · Motion Graphics · Corporate
        </div>
      </div>
    ),
    size,
  );
}
