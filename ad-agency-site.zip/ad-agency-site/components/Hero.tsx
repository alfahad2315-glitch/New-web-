"use client";

import Link from "next/link";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { ui } from "@/lib/ui";
import { clients, site, stats } from "@/lib/site-config";
import VideoLightbox, { type LightboxVideo } from "./VideoLightbox";

export default function Hero() {
  const { t } = useLang();
  const [reel, setReel] = useState<LightboxVideo | null>(null);

  return (
    <>
      <section className="grain relative flex min-h-[100svh] items-end overflow-hidden">
        {/* Background showreel: autoplay, muted, looped */}
        <video
          className="absolute inset-0 h-full w-full object-cover"
          src={site.showreelMp4}
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          aria-hidden
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/70 to-ink/30" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink/80 to-transparent" />

        <div className="relative z-10 mx-auto w-full max-w-7xl px-5 pb-16 pt-32 sm:pb-24">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-semibold kicker uppercase tracking-[0.2em] backdrop-blur">
            <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" /> {t(ui.hero_kicker)}
          </p>
          <h1 className="max-w-4xl font-display text-5xl font-extrabold leading-[1.02] tracking-tight sm:text-7xl lg:text-8xl">
            {t(ui.hero_title_1)} <span className="text-gradient">{t(ui.hero_title_2)}</span>
          </h1>
          <p className="mt-6 max-w-xl text-lg text-white/75">{t(ui.hero_sub)}</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/contact" className="rounded-full bg-accent px-8 py-4 font-semibold text-black transition hover:brightness-110">
              {t(ui.get_quote)} →
            </Link>
            <button
              onClick={() => setReel({ platform: "youtube", videoId: site.showreelYoutubeId, title: "Showreel" })}
              className="flex items-center gap-3 rounded-full border border-white/25 bg-white/5 px-7 py-4 font-semibold backdrop-blur transition hover:bg-white/15"
            >
              <span className="grid h-6 w-6 place-items-center rounded-full bg-white text-black">
                <svg viewBox="0 0 24 24" className="ml-0.5 h-3 w-3 fill-current" aria-hidden><path d="M8 5v14l11-7z" /></svg>
              </span>
              {t(ui.watch_reel)}
            </button>
          </div>

          <dl className="mt-14 grid max-w-3xl grid-cols-2 gap-6 sm:grid-cols-4">
            {stats.map((s) => (
              <div key={s.value}>
                <dt className="sr-only">{t(s.label)}</dt>
                <dd className="font-display text-3xl font-extrabold">{s.value}</dd>
                <dd className="text-sm text-muted">{t(s.label)}</dd>
              </div>
            ))}
          </dl>
        </div>
      </section>

      {/* Client logos marquee — replace names with logo images later if you like */}
      <section className="border-y border-line py-8" aria-label={t(ui.trusted_by)}>
        <p className="mb-6 text-center kicker text-xs uppercase tracking-[0.25em] text-muted">{t(ui.trusted_by)}</p>
        <div className="relative overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_15%,#000_85%,transparent)]">
          <div className="marquee flex w-max gap-14">
            {[...clients, ...clients].map((c, i) => (
              <span key={i} className="font-display text-2xl font-bold whitespace-nowrap text-white/35">
                {c}
              </span>
            ))}
          </div>
        </div>
      </section>

      <VideoLightbox video={reel} onClose={() => setReel(null)} />
    </>
  );
}
