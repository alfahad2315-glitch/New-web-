// Sends you an email for every new lead, using the Resend API.
import type { Lead } from "./leads";
import { site } from "./site-config";

const esc = (s: string) =>
  s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

export async function sendLeadEmail(lead: Lead) {
  const apiKey = process.env.RESEND_API_KEY;
  const to = process.env.LEADS_EMAIL_TO;
  if (!apiKey || !to) {
    console.warn("[email] RESEND_API_KEY or LEADS_EMAIL_TO missing — email not sent.");
    return;
  }
  const from = process.env.LEADS_EMAIL_FROM || "Website Leads <onboarding@resend.dev>";

  const rows: [string, string | null][] = [
    ["Company", lead.company],
    ["Contact", lead.contact_name],
    ["Phone / WhatsApp", lead.phone],
    ["Email", lead.email],
    ["Video type", lead.video_type],
    ["Length", lead.length],
    ["Budget", lead.budget],
    ["Deadline", lead.deadline],
    ["Package", lead.package],
    ["References", lead.reference_links],
    ["Details", lead.details],
    ["Attachment", lead.file_path ? "Yes — open the admin page to download" : "No"],
  ];

  const html = `
    <h2>New quote request — ${esc(lead.company)}</h2>
    <table cellpadding="6" style="border-collapse:collapse;font-family:sans-serif;font-size:14px">
      ${rows
        .filter(([, v]) => v)
        .map(([k, v]) => `<tr><td style="color:#666;vertical-align:top"><b>${k}</b></td><td style="white-space:pre-wrap">${esc(v!)}</td></tr>`)
        .join("")}
    </table>
    <p><a href="${site.url}/admin">Open admin dashboard</a> ·
       <a href="https://wa.me/${lead.phone.replace(/\D/g, "")}">WhatsApp them</a></p>`;

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: to.split(",").map((s) => s.trim()),
      reply_to: lead.email,
      subject: `🎬 New lead: ${lead.company} (${lead.video_type})`,
      html,
    }),
  });
  if (!res.ok) console.error("[email] Resend error:", res.status, await res.text());
}
